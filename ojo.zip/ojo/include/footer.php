<html>
<footer class="footer bg-dark text-white pt-5">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h5>About Us</h5>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec euismod lacus ac felis consectetur, in scelerisque metus tristique.</p>
      </div>
      <div class="col-md-6">
      <div class="col-lg p-2 my-2 bg-dark text-white">
          <h3>Our cool things</h3>
          <ul class="list-group list-group-flush bg-dark text-white">
            <li class="list-group-item"><a href="admin/login.php">Admin Room's</a></li>
            <li class="list-group-item"><a href="include/signin.php">Terms and Conditions</a></li>
            <li class="list-group-item"><a href="#">Privacy Policy</a></li>
          </ul>
        </div>  
    </div>
    </div>
  </div>
</footer>
</html>